import Index from './pages'

function App() {
  return (
    <div className="App">
      <Index />
    </div>
  )
}

export default App
