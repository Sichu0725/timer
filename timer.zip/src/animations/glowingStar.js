import img from './a.gif'
import '../style/glowing_star.scss'

const GlowingStar = () => {
  return (
    <>
      <img src={img} alt="" />
    </>
  )
}

export default GlowingStar
